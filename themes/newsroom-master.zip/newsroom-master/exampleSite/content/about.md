+++
title = "About Hugo"
date = "2014-04-09"
image = 'street.jpg'
+++

Hugo is the **world’s fastest framework for building websites**. It is written in Go.

It makes use of a variety of open source projects including:

* [https://github.com/russross/blackfriday](https://github.com/russross/blackfriday)
* [https://github.com/alecthomas/chroma](https://github.com/alecthomas/chroma)
* [https://github.com/muesli/smartcrop](https://github.com/muesli/smartcrop)
* [https://github.com/spf13/cobra](https://github.com/muesli/smartcrop)
* [https://github.com/spf13/viper](https://github.com/muesli/smartcrop)

Learn more and contribute on [GitHub](https://github.com/gohugoio).
